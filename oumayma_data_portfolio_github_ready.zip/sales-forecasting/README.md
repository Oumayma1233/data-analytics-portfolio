# Sales Forecasting with Machine Learning

## Objective
Predict weekly sales to improve stock and business planning.

## Dataset
Retail / Walmart sales dataset.

## Techniques Used
- Exploratory Data Analysis
- Feature Engineering
- Random Forest Regression
- Model evaluation with cross validation

## Workflow
1. Load dataset
2. Feature engineering (date features)
3. Train Random Forest model
4. Evaluate performance
5. Visualize predictions

## Technologies
Python, Pandas, Scikit-learn, Matplotlib

## Expected Output
- Forecast of weekly sales
- Feature importance analysis