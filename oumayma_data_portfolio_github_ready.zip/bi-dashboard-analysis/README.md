# Business Intelligence Dashboard Analysis

## Objective
Create a business dashboard to track key KPIs.

## Dataset
E-commerce transactions dataset.

## KPIs
- Revenue
- Profit margin
- Product performance
- Customer Lifetime Value

## Workflow
1. Data cleaning with Python / SQL
2. KPI aggregation
3. Export processed dataset
4. Build Power BI dashboard

## Technologies
Python, SQL, Power BI

## Expected Output
- Interactive dashboard showing business performance