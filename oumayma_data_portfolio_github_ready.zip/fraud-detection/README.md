# Fraud Detection using Machine Learning

## Objective
Detect fraudulent financial transactions.

## Dataset
Credit Card Fraud Dataset.

## Techniques Used
- Exploratory Data Analysis
- Isolation Forest anomaly detection
- Logistic Regression classification

## Workflow
1. Load dataset
2. Explore class imbalance
3. Train anomaly detection model
4. Evaluate performance metrics

## Technologies
Python, Scikit-learn, Pandas

## Expected Output
- Detection of suspicious transactions
- Evaluation metrics (precision, recall)