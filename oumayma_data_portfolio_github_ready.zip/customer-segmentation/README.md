# Customer Segmentation with PCA and K-Means

## Objective
Segment customers based on purchasing behavior to support targeted marketing strategies.

## Dataset
Online Retail Dataset (transactions).

## Techniques Used
- Exploratory Data Analysis (EDA)
- Feature Engineering
- Principal Component Analysis (PCA)
- K-Means Clustering

## Workflow
1. Load and clean transaction data
2. Create RFM features (Recency, Frequency, Monetary)
3. Standardize features
4. Apply PCA for dimensionality reduction
5. Apply K-Means clustering
6. Interpret customer segments

## Technologies
Python, Pandas, Scikit-learn, Matplotlib, Seaborn

## Expected Output
- Identification of 4–6 customer segments
- Visualizations of clusters
- Business interpretation of each segment